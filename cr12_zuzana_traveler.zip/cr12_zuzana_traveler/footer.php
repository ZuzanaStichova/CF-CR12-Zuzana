<!-- Footer + footer widgets-->
<footer class="page-footer font-small bg-dark darken-3">
  <?php
    if(is_active_sidebar('sidebar-2')):
      dynamic_sidebar('sidebar-2');
    endif;  
  ?>
  <div class="footer-copyright text-center py-3 text-white">© 2020 Copyright:
    <a href="#" class="text-white"> CF</a>
  </div>
</footer>

  <?php wp_footer(); ?>
</body>
</html>