<div class="hero jumbotron-fluid">
</div>

<?php get_header(); ?>
   
<!-- Page -->
<div class="container">
  <div class="row">
    <?php if(have_posts()) : ?>
      <?php while(have_posts()) : the_post(); ?>
        <div class="col-md-9">
          <h2 class="mt-5 mb-5"><b><i><?php the_title(); ?></b></i></h2>
          <p class="text-justify"><?php the_content(); ?></p>
          <p class="card-text"><small class="text-muted date"><?php the_date(); ?></small></p>
        </div>
      <?php endwhile; ?>
    <?php else :?>
      <p>No page found</p>
    <?php endif; ?> 

<!-- Widgets -->
    <div class="col-md-3 mt-5">
      <?php
        if(is_active_sidebar('sidebar-1')):
          dynamic_sidebar('sidebar-1');
        endif;  
      ?>
    </div>
    
  </div>    
</div>

<?php get_footer(); ?>