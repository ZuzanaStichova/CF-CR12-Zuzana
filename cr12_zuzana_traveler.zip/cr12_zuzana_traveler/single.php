<div class="hero jumbotron-fluid">
</div> 

<?php get_header(); ?>
   
<!-- Single article part -->
<div class="container">
  
  <div class="row">
    <?php if(have_posts()) : ?>
      <?php while(have_posts()) : the_post(); ?>
        <div class="col-md-9">
          <h2 class="mt-5 mb-5"><b><i><?php the_title(); ?></b></i></h2>
          <p class="text-muted mb-5"><small>Written by <?php the_author(); ?>, <?php the_date(); ?></small></p>
          <img class="float-left mr-4 mb-4" src="<?php the_post_thumbnail_url('medium'); ?>" alt="post_pic">
          <p class="text-justify"><?php the_content(); ?></p>
          <p class="card-text"><small class="text-muted date"><?php the_date(); ?></small></p>
        </div>        
      <?php endwhile; ?>
    <?php else :?>
      <p>No posts found</p>
    <?php endif; ?> 

<!-- Widget part -->
    <div class="col-md-3 mt-5">
      <?php
        if(is_active_sidebar('sidebar-1')):
          dynamic_sidebar('sidebar-1');
        endif;  
      ?>
    </div>
    
  </div>  

<!-- Part for comments -->
  <h2 class="mt-5 mb-2 text-center">Comments</h2>
  <div class="mt-5">
    <?php if ( comments_open() || get_comments_number() ) :
      comments_template();
    endif; ?>
  </div>

</div>

<?php get_footer(); ?>