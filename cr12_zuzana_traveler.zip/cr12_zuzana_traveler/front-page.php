<?php get_header(); ?>

<div class="jumbotron jumbotron-fluid">
  <div class="container text-center">
    <h1 class="display-3"><?php echo get_bloginfo('name'); ?></h1>
    <p class="lead"><?php echo get_bloginfo('description'); ?></p>
  </div>
</div>

<?php get_footer(); ?>