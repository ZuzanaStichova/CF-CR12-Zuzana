<div class="container">

<!-- Arguments for styling comments   -->
  <?php 
    $arg_comments = array(
      'label_submit'         => __('Comment')
    );
  ?>

  <?php
    $args = array(
      'max_depth'         => '2',
      'style'             => 'div',
      'avatar_size'       => 70,
    );
  ?>

  <?php wp_list_comments($args); ?>
  <?php comment_form($arg_comments); ?>

</div>