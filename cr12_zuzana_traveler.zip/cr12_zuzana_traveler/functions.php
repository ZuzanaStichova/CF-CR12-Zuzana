<?php


/**
* Register Bootstrap, jquery, css style sheet
*/
function register_files() {
  wp_enqueue_style('bootstrap-css',get_template_directory_uri().'/css/bootstrap.css');
  wp_enqueue_script('bootstrap-js',get_template_directory_uri().'/js/bootstrap.js',array(),'1.0',true);
  wp_enqueue_style('style-sheet',get_template_directory_uri().'/style.css');
  wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.5.1.js',array(),'1.0',true);
}

add_action('wp_enqueue_scripts','register_files');


/**
* Register Custom Navigation Walker
*/
function register_navwalker(){
  require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
  register_nav_menus( array(
'primary' => __( 'Top-Menu'),
) );
}

add_action('after_setup_theme','register_navwalker');


/**
* Set length of posts
*/
function set_excerpt_length() {
  return 40;
}

add_filter('excerpt_length','set_excerpt_length');

/**
* Thumbnails
*/
add_theme_support('post-thumbnails');


/**
* Register widgets
*/
function wpb_init_widgets(){
  register_sidebar(
    array(
      'name' => 'Sidebar',
      'id' => 'sidebar-1',
      'before_widget' => '<div class="sidebar-module mb-2 text-center widget"><p class="text-center">',
      'after_widget' => '</p></div>',
      'before_title' => '<h4 class="text-muted">',
      'after_title' => '</h4>'
       )
  );

  register_sidebar(
    array(
      'name' => 'Footer Sidebar',
      'id' => 'sidebar-2',
      'before_widget' => '<div class="sidebar-module mb-2 text-center">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="text-muted">',
      'after_title' => '</h4>'
       )
  );
}

add_action('widgets_init', 'wpb_init_widgets');


?>