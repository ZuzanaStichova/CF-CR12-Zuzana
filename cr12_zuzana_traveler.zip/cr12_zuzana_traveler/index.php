<div class="hero jumbotron-fluid">
</div>

<!-- Header -->
  <?php get_header(); ?>

<!-- Post part -->
  <div class="container">
    <h1 class="display-5 text-center m-5"><?php echo get_bloginfo('name'); ?></h1>
    <div class="row">
      
      <?php if(have_posts()) : ?>
        <div class="col-9 row">
          <?php while(have_posts()) : the_post(); ?>      
            <div class="col-md-12 media mb-5">
              <div class="media-body">
                <h4 class="mt-1 mb-1"><b><i><?php the_title(); ?></b></i></h4>
                <div class="row">
                  <img class="col-md-3 p-1 border" src="<?php the_post_thumbnail_url('thumbnail'); ?>" alt="post_pic">
                  <div class="col-md-8">
                    <p><?php the_excerpt(); ?></p>
                    <p class="card-text"><small class="text-muted date"><?php the_date(); ?></small></p>
                    <a  ></a><p><?php comments_number(); ?></p>
                    <a class="btn btn-dark" href="<?php the_permalink(); ?>">Read more &rarr;</a>
                  </div>
                </div>
              </div>
            </div>
            <hr>
          
          <?php endwhile; ?>
        </div>
      <?php else :?>
        <p>No posts found</p>
      <?php endif; ?> 

      <div class="col-md-3">
        <?php
          if(is_active_sidebar('sidebar-1')):
            dynamic_sidebar('sidebar-1');
          endif;  
        ?>
      </div>

    </div>
  </div>

<!-- Footer -->
  <?php get_footer(); ?>